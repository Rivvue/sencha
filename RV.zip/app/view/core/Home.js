Ext.define('RV.view.core.Home', {
    extend: 'Ext.tab.Panel',
    xtype: 'home',

	config:{
		fullscreen: true,
		tabBarPosition: 'bottom',
		defaults: {
			styleHtmlContent: true
		},
		ui:'main-tabbar',
		 items: [
			{
				xtype:'calenderpagenavigation'
			},
			{
				title: 'CONTACTS',
				iconCls: 'chat2',
				html: 'Contact Screen'
			},
			{
				xtype:'createevent'
			},
			{
				xtype:'notificationnavigation'
			}
		]
	}
});
