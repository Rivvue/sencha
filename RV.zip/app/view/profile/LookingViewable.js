Ext.define('RV.view.profile.LookingViewable', {
    extend: 'Ext.Panel',
    xtype: 'lookingviewable',
	requires:['Ext.field.Radio'],
	config:{
		layout:{type:'vbox'},
		items: [
			{
								xtype : 'toolbar',
								padding:10,
								ui:'white-toolbar',
								docked: 'top',
								items:[
									{
										xtype:'component',
										html:'<a class="toolbar-links"><b style="font-size:16px;"><</b></a>',
										listeners: [
												{
													element: 'element',
													delegate: 'a.toolbar-links',
													event: 'tap',
													fn: function() {
														this.up('calenderpagenavigation').pop();
													}
												}
											]
									},
									{
										xtype:'spacer'
									},
									{
										xtype:'component',
										html:'<span class="createEvent">Looking For & Viewable</span>'
									},
									{
										xtype:'spacer'
									},
									{
										xtype:'component',
										html:'<a class="toolbar-links">DONE</h1>'
									},
								]
			},			
			{
						xtype: 'fieldset',
						title:'Who all can Attend',
						flex:1,
						cls:'search-invites',
						items: [
							{
								xtype: 'textareafield',
								placeHolder:'Enter Here'
							}							
						]
			},
			{
						xtype: 'fieldset',
						scrollable:true,
						title:'Who all can View',
						margin:'10 0 0 0',
						flex:1,
						cls:'search-invites',
						instructions:'Using the audience selector right where you post events. This control remembers your selection so future posts will be shared'
						+'',
						defaults:{
							xtype:'radiofield',
							labelWidth:'35%'
						},
						items: [
									{
										name:'visible',
										label:'Public',
										labelCls:'public-icon',
										value:'Public'
									},
									{
										name:'visible',
										label:'Friends',
										labelCls:'friends-icon',
										value:'Friends'
									},
									{
										name:'visible',
										label:'Invitees',
										labelCls:'invitees-icon',
										value:'Invitees'
									},
									{
										name:'visible',
										label:'Only Me',										
										labelCls:'only-me-icon',
										value:'Only Me'
									}
							]
			},
			
		]
	}
});
