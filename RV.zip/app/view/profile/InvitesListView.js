Ext.define('RV.view.profile.InvitesListView',{
	extend:'Ext.dataview.List',
	alias:'widget.inviteslistview',
	config:
	{
		scrollable:{
			direction:'vertical'
		},
		style:'backgroundColor:#ffffff;',
		baseCls:'invitelistview-basic',
		itemTpl: '<div class="invite-cont"><div class="invite-image"></div><div class="invite-name">{name}</div><div class="invite-button-cont"></div></div>',
		store:'InvitesStore',
		listeners : {
			'painted' : function(e){
			var btn = e.dom.getElementsByClassName('invite-button-cont');			
			
			Ext.each(btn, function(item) {
			var checkBtn = item.getElementsByClassName('check-btn');
			if(checkBtn.length==0){
						var button = Ext.create('Ext.field.Checkbox', {
									cls:'check-btn',
									renderTo : item
								});
							}
					});
			}
		}
	}
});