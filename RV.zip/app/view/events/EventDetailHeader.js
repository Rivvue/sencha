Ext.define('RV.view.events.EventDetailHeader',{
	extend:'Ext.dataview.DataView',
	alias:'widget.eventdetailheader',
	config:
	{
		scrollable:{
			direction:'vertical'
		},
		cls:'dataview-basic',
		itemTpl:new Ext.XTemplate(
		'<table class="eventList">'+
		'<tr>'+
		'<td rowspan="3" class="img" style="background-image :url({photo});"></td>'+
		'<td class="eventHeader">{name}</td>  <td class="time">{time}</td>'+
		'</tr> '+
		'<tr>'+
		'<td class="eventLocation">{location}</td> <td class="temperature"><div style="float:right;" class="time-{timeType}">{temperature}</div></td>'+
		'</tr>'+
		'<tr>'+
		'<td class="ratings">{ratingObj:this.getRatingBasedOnType}</td></td>'+
		'</tr>'+
		'</table>',
		{
		getRatingBasedOnType : function(ratingObj){
		
			var ratingStr='';
			if(ratingObj['ratingType']=='type3')
					ratingStr +="<img src='resources/icons/measure.png' height=13 />";
			else
			for(var i=0;i<ratingObj['rating'];i++){
				if(ratingObj['ratingType']=='type1')
					ratingStr +="<img src='resources/icons/rating.png' width=16 height=16 />";
				else
					ratingStr +="<img src='resources/icons/rating1.png' width=16 height=16 />";
				}
				return ratingStr;
			}	
			
		}
		),
		store:'MyEventsStore'
	}
});