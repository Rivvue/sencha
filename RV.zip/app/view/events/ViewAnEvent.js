Ext.define('RV.view.events.ViewAnEvent',{
	extend:'Ext.Container',
	xtype: 'viewanevent',
	requires: [
		'Ext.form.FieldSet',
		'Ext.field.Toggle',
		'Ext.field.Select',
		'Ext.field.Checkbox'					
    ],
	
    config: {
				iconCls: 'team',
				title: 'EVENTS',
				scrollable:true,
				minHeight:500,
				autoScroll:true,
				layout:{type:'vbox'},
				padding:0,
				margin:0,
				items:[		
					{
								xtype : 'toolbar',
								padding:10,
								ui:'white-toolbar',
								docked: 'top',
								items:[
									{
										xtype:'component',
										html:'<a class="toolbar-links"><b style="font-size:16px;"><</b></a>',
										listeners: [
												{
													element: 'element',
													delegate: 'a.toolbar-links',
													event: 'tap',
													fn: function() {
														this.up('notificationnavigation').pop();
													}
												}
											]
									},
									{
										xtype:'spacer'
									},
									{
										xtype:'component',
										itemId:'eventHeader'
										
									},
									{
										xtype:'spacer'
									},
									{
										xtype:'component',
										html:'<img class="createEvent" src="resources/icons/plus.png" style="cursor:pointer" />',
										listeners: [
												{
													element: 'element',
													delegate: 'img.createEvent',
													event: 'tap',
													fn: function() {
														this.up('notificationnavigation').push({xtype:'createevent'});
													}
												}
											]
									}
								]
					},
					{
						xtype: 'fieldset',
						margin:'5 0 10 0',
						items: [
							{
								xtype: 'textfield',
								readOnly:true,
								padding:10,
								labelCls:'plain-label location-icon',
								margin:'10 0 0 0',
								labelAlign:'left',
								label:' ',
								labelWidth:50,
								value:'Santa Monica, CA, US',
								name: 'where'
							}							
						]
					},
						/*{
							xtype: 'panel',
							height:500,
							layout: 'card',
							title:'Test',
							margin:'20 0 0 0',
							flex:2,
							items: [
									{
									xtype: 'map',
									useCurrentLocation: true,
									mapOptions: {
									zoom: 15,
									height:300,
									mapTypeId: google.maps.MapTypeId.ROADMAP
									},
									listeners: {
										maprender: function(map,gmap,options){
											
										}
									}									
								}
							]
						}*/
						{
						xtype: 'fieldset',
						margin:'10 0 5 0',
						items: [
							{
								xtype: 'textfield',
								readOnly:true,
								padding:5,
								labelCls:'plain-label friends-icon',
								margin:'10 0 0 0',
								labelAlign:'left',
								label:' ',
								labelWidth:50,
								value:'Confirmed Participants (4)',
								name: 'where'
							}							
							]
						},
						{
						xtype: 'panel',
						height:500,
						layout:'fit',
						items: [
							{xtype:'participantslist'}
							]
						},
						
						{
									xtype: 'panel',
									height:50,
									layout:'fit',
									scrollable:false,
									margin:'20 0 10 0',
									items: [
										{
											xtype: 'component',
											html:'<div class="disclosure-component"><div class="disclosure-header">Event Pictures (Post Event Activity)</div><div class="disclosure-action">></div></div>'
										}
									]
						}
						
					]
			},
			
			setEventInfo : function(eventRecord){
				this.down('#eventHeader').setHtml('<span class="eventHeader">'+eventRecord.get('event') +'</span><br/><center><span class="eventSubHeader">'+eventRecord.get('invitee')+'</span></center>');
			}
});